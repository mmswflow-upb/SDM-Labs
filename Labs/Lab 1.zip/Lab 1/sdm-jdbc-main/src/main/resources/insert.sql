INSERT INTO addresses (city, street) VALUES ('Bucuresti', 'Politehnicii');
INSERT INTO addresses (city, street) VALUES ('Ploiesti', 'Independetei');
INSERT INTO persons (name, address) VALUES ('Vasile', 1);
INSERT INTO persons (name, address) VALUES ('John', 1);
INSERT INTO persons (name, address) VALUES ('Emily', 2);